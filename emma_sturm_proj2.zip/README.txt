Name: Emma Sturm
Date: 01/18/2025
Project 2: HTML Pet Sitting Webpage
Email address: emma.sturm99@gmail.com
Files in this archive:
    -about.html: about page for the website
    -contact.html: contact information request page for the website
    -index.html: main home page for the website
    -README: file gives short description of files in the archive
    -video.mp4: video clip showing dog
    -DOMContact_Page.pdf: DOM drawing of the Contact page
    -SEOandAccessibility.txt: Paragraph explaining SEO/Accessbility design in website. Link to GitHub website also included here. 

GitHub website link:  https://esturm18.github.io/Pet-Sitting-Website/